const habitInput = document.getElementById("habit-input");

const addHabitButton =
    document.getElementById("add-habit-button");

const habitList =
    document.getElementById("habit-list");

const emptyMessage =
    document.getElementById("empty-message");

const getStartedButton =
    document.getElementById("get-started");


let habits =
    JSON.parse(localStorage.getItem("streakifyHabits")) || [];


function saveHabits() {

    localStorage.setItem(
        "streakifyHabits",
        JSON.stringify(habits)
    );

}


function getToday() {

    const today = new Date();

    return today.toISOString().split("T")[0];

}


function calculateStreak(completedDates) {

    if (completedDates.length === 0) {
        return 0;
    }

    const dates =
        [...completedDates].sort().reverse();

    let streak = 0;

    let currentDate = new Date();


    for (let i = 0; i < dates.length; i++) {

        const dateString =
            currentDate.toISOString().split("T")[0];


        if (dates[i] === dateString) {

            streak++;

            currentDate.setDate(
                currentDate.getDate() - 1
            );

        } else {

            break;

        }

    }


    return streak;
}


function displayHabits() {

    habitList.innerHTML = "";


    if (habits.length === 0) {

        emptyMessage.style.display = "block";

        return;

    }


    emptyMessage.style.display = "none";


    habits.forEach(function(habit) {

        const card =
            document.createElement("div");

        card.className = "habit-card";


        const info =
            document.createElement("div");

        info.className = "habit-info";


        const name =
            document.createElement("p");

        name.className = "habit-name";

        name.textContent = habit.name;


        const streak =
            document.createElement("p");

        streak.className = "streak";


        const currentStreak =
            calculateStreak(habit.completedDates);


        streak.textContent =
            `🔥 ${currentStreak} day streak`;


        info.appendChild(name);

        info.appendChild(streak);


        const actions =
            document.createElement("div");

        actions.className = "habit-actions";


        const completeButton =
            document.createElement("button");

        completeButton.className =
            "complete-button";


        const today = getToday();


        if (habit.completedDates.includes(today)) {

            completeButton.textContent =
                "Completed ✓";

            completeButton.classList.add("completed");

        } else {

            completeButton.textContent =
                "Complete";

        }


        completeButton.addEventListener(
            "click",
            function() {

                completeHabit(habit.id);

            }
        );


        const deleteButton =
            document.createElement("button");

        deleteButton.className =
            "delete-button";

        deleteButton.textContent =
            "Delete";


        deleteButton.addEventListener(
            "click",
            function() {

                deleteHabit(habit.id);

            }
        );


        actions.appendChild(completeButton);

        actions.appendChild(deleteButton);


        card.appendChild(info);

        card.appendChild(actions);


        habitList.appendChild(card);

    });

}


function addHabit() {

    const habitName =
        habitInput.value.trim();


    if (habitName === "") {

        alert("Please enter a habit.");

        return;

    }


    const newHabit = {

        id: Date.now(),

        name: habitName,

        completedDates: []

    };


    habits.push(newHabit);


    saveHabits();

    displayHabits();


    habitInput.value = "";

    habitInput.focus();

}


function completeHabit(habitId) {

    const habit =
        habits.find(function(item) {

            return item.id === habitId;

        });


    if (!habit) {
        return;
    }


    const today = getToday();


    if (habit.completedDates.includes(today)) {
        return;
    }


    habit.completedDates.push(today);


    saveHabits();

    displayHabits();

}


function deleteHabit(habitId) {

    habits =
        habits.filter(function(habit) {

            return habit.id !== habitId;

        });


    saveHabits();

    displayHabits();

}


addHabitButton.addEventListener(
    "click",
    addHabit
);


habitInput.addEventListener(
    "keydown",
    function(event) {

        if (event.key === "Enter") {

            addHabit();

        }

    }
);


getStartedButton.addEventListener(
    "click",
    function() {

        document
            .getElementById("tracker")
            .scrollIntoView({
                behavior: "smooth"
            });

    }
);


displayHabits();

